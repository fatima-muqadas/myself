import { Component } from '@angular/core';
//import projectData from '../project.json';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {MatTableModule} from '@angular/material/table';

  
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
  

interface Project{
  id:Number,
  name:string
}
@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css'],
  
 

 
})

export class ProjectComponent {
  
   // projects:Project[]=projectData;

    displayedColumns: string[] = ['id', 'name'];
  //  dataSource = this.projects;
   
   
}
