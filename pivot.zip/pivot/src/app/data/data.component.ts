import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

interface Item {
  employee?: string;
  Taskid: number;
  Descryption: string;
  project: string;
}

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent implements OnInit {
  jsonData: Item[] = [];
  recordCount: number = 0;
  groupedData: { [project: string]: Item[] } = {};
  uniqueEmployees: any[]=[];
  uniqueProjects: any[]=[];
  constructor(private http: HttpClient) { }

  fetchData(): void {
    // Assuming you have a JSON file named 'data.json' in your assets folder
    this.http.get<Item[]>('/assets/data.json').subscribe((data) => {
      this.jsonData = data;
      this.groupData();
       this.uniqueEmployees= Array.from(new Set(this.jsonData.map(item => item.employee)));
       this.uniqueProjects= Array.from(new Set(this.jsonData.map(item => item.project)));
    });
  }

  groupData() {
    this.groupedData = this.jsonData.reduce((acc, item) => {
      const key = `${item.employee}-${item.project}`;
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(item);
      return acc;
    }, {} as { [project: string]: Item[] });
  }

  getProjects(): string[] {
    return Object.keys(this.groupedData);
  }

  getProjectCount(project: string): number {
    return this.groupedData[project]?.length || 0;
  }

  getEmployeeProjects(employee: string): string[] {
    return this.jsonData.filter(item => item.employee === employee)
      .map(item => item.project)
      .filter((value, index, self) => self.indexOf(value) === index);
  }

  getProjectCountForEmployee(employee: any, project: any): boolean {
    this.recordCount=0;
      this.recordCount = this.jsonData.filter(item => item.employee === employee && item.project === project).length;
      if(this.recordCount)
      {
        return true;
      }
    return false;
  }

  ngOnInit(): void {
    this.fetchData();
  }
}
