import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
interface Item {
  
  name?: string;
 
 
  project:string;
}
@Component({
  selector: 'app-counter',
  templateUrl: './counter.component.html',
  styleUrls: ['./counter.component.css']
})
export class CounterComponent {
  jsonData: Item[] = [];
  recordCount: number = 0;
  constructor(private http: HttpClient) {}
  ngOnInit(): void {
    this.fetchData();
  }

  fetchData(): void {
    // Assuming you have a JSON file named 'data.json' in your assets folder
  this.http.get<Item[]>('/assets/list.json').subscribe((data) => {
    this.jsonData = data;

    // Filter the data where project is equal to 'KCBL'
    const filteredData = this.jsonData.filter(item => item.project === 'KCBL'&& item.name === 'sara');

    // Update the recordCount with the length of the filtered data
    this.recordCount = filteredData.length;
  });
  }
}
