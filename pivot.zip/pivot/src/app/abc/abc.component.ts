import { Component } from '@angular/core';

@Component({
  selector: 'app-abc',
  templateUrl: './abc.component.html',
  styleUrls: ['./abc.component.css']
})
export class AbcComponent {
 // Sample data for demonstration purposes
dataVertical: any[] = [
  { name: 'John', age: 25, city: 'New York' },
  { name: 'Alice', age: 30, city: 'Los Angeles' },
  { name: 'Bob', age: 28, city: 'Chicago' },
];

dataHorizontal: any[] = [
  { category: 'Category A', value1: 10, value2: 20, value3: 30 },
  { category: 'Category B', value1: 15, value2: 25, value3: 35 },
];

dataMultipleTables: any[] = [
  { id: 1, name: 'Product A', price: 100 },
  { id: 2, name: 'Product B', price: 150 },
  { id: 3, name: 'Product C', price: 200 },
];

}
