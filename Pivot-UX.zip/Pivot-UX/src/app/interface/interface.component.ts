import { Component, OnInit } from '@angular/core';

import { DataserviceService} from '../dataservice.service';
import { ActivatedRoute} from '@angular/router';
import { Router } from '@angular/router';

interface Item {
  Taskid?: number;
  name?: string;
  Descryption?: string;
 
  project:string;
}

@Component({
  selector: 'app-interface',
  templateUrl: './interface.component.html',
  styleUrls: ['./interface.component.css']
})
export class InterfaceComponent {
  resource: any[] = [];
  task: any[] = [];
  constructor(private dataService: DataserviceService,private route: ActivatedRoute, private router:Router) {}
  
  ngOnInit(): void {
    this.dataService.getData1().subscribe(response => {
      this.resource = response;
      console.log(this.resource);
      this.groupData(this.resource, item => item.project =="KCBL");
      console.log(this.groupedData);
    });
  
    this.dataService.getData2().subscribe(response => {
      this.task = response;
      console.log(this.task);
     
      console.log(this.groupedData);
    });
  }
  groupedData: { [key: string]: Item[] } = {};
  
  groupData(data: Item[], whereCondition: (item: Item) => boolean) {
    data.forEach(item => {
      if (whereCondition(item)) {
        if (!this.groupedData[item.project]) {
          this.groupedData[item.project] = [];
        }
        this.groupedData[item.project].push(item);
      }
    });
  }
  getTotalNoForProject(projectKey: string): number {
  const projectData = this.groupedData[projectKey];
  if (!projectData) {
    return 0;
  }

  let totalNo = 0;
  projectData.forEach((item) => {
    totalNo += item.Taskid || 0;
  });

  return totalNo;

  
}
 

}
