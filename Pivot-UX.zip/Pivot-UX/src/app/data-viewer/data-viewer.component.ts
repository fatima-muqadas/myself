import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as XLSX from 'xlsx';

import { Router } from '@angular/router';


interface Item {
  [key: string]: any;
  employee?: string;
  Taskid: number;
  Descryption: string;
  project: string;
}

@Component({
  selector: 'app-data-viewer',
  templateUrl: './data-viewer.component.html',
  styleUrls: ['./data-viewer.component.css']
})
export class DataViewerComponent implements OnInit {
  jsonData: Item[] = [];
  filteredData: any[] = [];
  whereConditions: { field: keyof Item; value: string | number }[] = [];
  fields: (keyof Item)[] = ['employee', 'Taskid', 'Descryption', 'project'];
  newField: keyof Item = 'employee';
  newValue: string = '';
  abc:any;
  abcd:any;
  qw:any=[];
  columnNames: string[] = [];
  selectedColumn: string | null = null;
  selectedColumns: string[] = []; // Array to store selected column names
  constructor(private http: HttpClient , private router: Router) { }

  ngOnInit(): void {
    this.fetchData();
     this.abc=history.state.employee;
     this.abcd=history.state.project;

  }

  fetchData(): void {
    this.http.get<Item[]>('/assets/data.json').subscribe((data) => {
      this.jsonData = data;
      this.filteredData = [];
    
      // Extract column names from the first record
      const firstRecord = this.jsonData[0]; // Assuming there's at least one record
      const columnNames: string[] = Object.keys(firstRecord);
    
      // Assuming you're storing columnNames in a variable
      this.columnNames = columnNames;
    
      this.jsonData.forEach((record) => {
        if (record.employee == this.abc && record.project == this.abcd) {
          this.filteredData.push(record);

        }
      });
    
      console.log(data);
    });
    
    
    
    
    
  }

  addWhereCondition(field: keyof Item, value: string | number): void {
    this.whereConditions.push({ field, value });
    this.applyWhereConditions();
  }

  removeWhereCondition(index: number): void {
    this.whereConditions.splice(index, 1);
    this.applyWhereConditions();
  }

  applyWhereConditions(): void {
    this.filteredData = this.jsonData.filter((item) => {
      for (const condition of this.whereConditions) {
        if (item[condition.field] !== condition.value) {
          return false;
        }
      }
      return true;
    });
  }

  exportToExcel(): void {
    const exportData: any[] = [];

    // Add headers
    const headerRow: any = {};
    for (const field of this.fields) {
      headerRow[field] = field;
    }
    exportData.push(headerRow);

    // Add rows
    for (const item of this.filteredData) {
      const rowData: any = {};
      for (const field of this.fields) {
        rowData[field] = item[field];
      }
      exportData.push(rowData);
    }

    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(exportData);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };

    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, 'table_data');
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url: string = window.URL.createObjectURL(data);
    const a: HTMLAnchorElement = document.createElement('a');
    a.href = url;
    a.download = fileName + '.xlsx';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }
  applyWhereCondition(field: keyof Item, item: Item): void {
    if (field === 'employee' && item.employee) {
      this.addWhereCondition('employee', item.employee);
    } else if (field === 'project' && item.project) {
      this.addWhereCondition('project', item.project);
      
    }
  }
  goToSelectedColumns(): void {
    const selectedColumnsRoute = '/column';
    this.router.navigate([selectedColumnsRoute]);
  }
  getLinkForEmployeeProject(): void {
    // Construct the link for the 'data-viewer' route and pass the project as a parameter
    this.router.navigate(['/column']);
  }
  onColumnClick(columnName: string): void {
    if (this.selectedColumn === columnName) {
      this.selectedColumn = null;
    } else {
      this.selectedColumn = columnName;
      this.addToSelectedColumns(columnName);
    }
  }
  removeFromSelectedColumns(columnName: string): void {
    const index = this.selectedColumns.indexOf(columnName);
    if (index !== -1) {
      this.selectedColumns.splice(index, 1);
      this.qw.splice(index, 1);
    }
  }

  addToSelectedColumns(columnName: string): void {
    if (!this.selectedColumns.includes(columnName)) {
      this.selectedColumns.push(columnName);
     
      // this.filteredData.forEach(data=>{
      //   if())
      //   this.qw.push(data[columnName]);
      //      console.log (this.qw);
           
      // })
      
    }
  }
  getfilterdata():void{

  }

}
