import { Component } from '@angular/core';
import { DataserviceService } from '../dataservice.service';

@Component({
  selector: 'app-column',
  templateUrl: './column.component.html',
  styleUrls: ['./column.component.css']
})
export class ColumnComponent {
  columnNames: string[] = [];
  selectedColumn: string | null = null;
  selectedColumns: string[] = []; // Array to store selected column names


  constructor(private dataserviceService: DataserviceService) {}

  ngOnInit(): void {
    this.dataserviceService.getData().subscribe(response => {
      if (Array.isArray(response) && response.length > 0) {
        this.columnNames = Object.keys(response[0]);
      }
    });
  }
  onColumnClick(columnName: string): void {
    if (this.selectedColumn === columnName) {
      this.selectedColumn = null;
    } else {
      this.selectedColumn = columnName;
      this.addToSelectedColumns(columnName);
    }
  }
  removeFromSelectedColumns(columnName: string): void {
    const index = this.selectedColumns.indexOf(columnName);
    if (index !== -1) {
      this.selectedColumns.splice(index, 1);
    }
  }

  addToSelectedColumns(columnName: string): void {
    if (!this.selectedColumns.includes(columnName)) {
      this.selectedColumns.push(columnName);
      console.log (this.selectedColumns)
    }
  }
  
}
