import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
interface Item {
  employee?: string;
  Taskid: number;
  Descryption: string;
  project: string;
}
@Injectable({
  providedIn: 'root'
})
export class DataserviceService {
  private jsonData: Item[] = [];
  constructor(private http: HttpClient) {}
 
 getData1(): Observable<any> {
   return this.http.get('assets/list.json');
 }

 getData2(): Observable<any> {
   return this.http.get('assets/project.json');
 }
 fetchData(): Observable<Item[]> {
  return this.http.get<Item[]>('/assets/data.json');
}
setData(data: Item[]): void {
  this.jsonData = data;
}

getDataa(): Item[] {
  return this.jsonData;
}


 private dataUrl = 'assets/data.json'; // Path to your JSON file

 

 getData(): Observable<any[]> {
   return this.http.get<any[]>(this.dataUrl);
 }
}

