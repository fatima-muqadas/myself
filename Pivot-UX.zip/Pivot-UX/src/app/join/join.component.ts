import { Component , OnInit} from '@angular/core';
import { DataserviceService} from '../dataservice.service';
interface Item {
  Taskid?: number;
  name?: string;
  title?: string;
 
  project:string;
}

@Component({
  selector: 'app-join',
  templateUrl: './join.component.html',
  styleUrls: ['./join.component.css']
})
export class JoinComponent {
  resource: any[] = [];
  task: any[] = [];
  
  constructor(private dataService: DataserviceService)
  
  
  {
    

  }
  ngOnInit(): void {
    this.dataService.getData1().subscribe(response=>{
      this.resource=response;
      console.log(this.resource);
      this.groupData(this.resource);

    
    });
    this.dataService.getData2().subscribe(response=>{
      this.task=response;
      console.log(this.task);
      this.groupData(this.task);


    
    });
    
    
    
  }
  groupedData: { [key: string]: Item[] } = {};
  groupData(data: Item[]) {
    data.forEach(item => {
      if (!this.groupedData[item.project]) {
        this.groupedData[item.project] = [];
        
      }
      this.groupedData[item.project].push(item);
      console.log(this.groupedData)
      
    });
  }
}
