import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as XLSX from 'xlsx';
import { Router } from '@angular/router';

interface Item {
  employee?: string;
  Taskid: number;
  Descryption: string;
  project: string;
}

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent implements OnInit {
  jsonData: Item[] = [];
  recordCount: number = 0;
  groupedData: { [project: string]: Item[] } = {};
  uniqueEmployees: any[]=[];
  uniqueProjects: any[]=[];
  route:any="data-viewer";
  t:number=0;
  constructor(private http: HttpClient,private router: Router) { }

  fetchData(): void {
    // Assuming you have a JSON file named 'data.json' in your assets folder
    this.http.get<Item[]>('/assets/data.json').subscribe((data) => {
      this.jsonData = data;
      this.groupData();
       this.uniqueEmployees= Array.from(new Set(this.jsonData.map(item => item.employee)));
       this.uniqueProjects = Array.from(new Set(this.jsonData.map(item => item.project)));
      
    });

    
  }
  getTotalForColumn(project: string): number {
    return this.uniqueEmployees.reduce((total, employee) => {
    
      return total + this.getProjectCountForEmployee(employee, project);
    }, 0);
  }
  getOverallTotal(): number {
    return this.uniqueProjects.reduce((total, project) => {
      return total + this.getTotalForColumn(project);
    }, 0);
  }
  getTotalForRow(employee: string): number {
    return this.uniqueProjects.reduce((total, project) => {
      return total + this.getProjectCountForEmployee(employee, project);
    }, 0);
  }
  getLinkForEmployeeProject(employee: string, project: string): void {
    // Construct the link for the 'data-viewer' route and pass the project as a parameter
    this.router.navigate(['/data-viewer'], { state: { employee,project } });
  }
  
  
  exportToExcel(): void {
    // Prepare the data for export
    const exportData: any[] = [];

    // Create a header row for the Excel file
    const headerRow: any = {};
    headerRow['Employee'] = 'Employee';

    for (const project of this.jsonData) {
      headerRow[project.project] = project.project;
    }

    exportData.push(headerRow);

    // Create rows for each employee with project counts
    for (const employee of this.uniqueEmployees) {
      const rowData: any = { 'Employee': employee };
      for (const project of this.jsonData) {
        rowData[project.project] = this.getProjectCountForEmployee(employee, project.project) || 0;
      }
      exportData.push(rowData);
    }

    // Convert data to Excel format
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(exportData);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };

    // Export the Excel file
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, 'table_data');
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url: string = window.URL.createObjectURL(data);
    const a: HTMLAnchorElement = document.createElement('a');
    a.href = url;
    a.download = fileName + '.xlsx';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }

  groupData() {
    this.groupedData = this.jsonData.reduce((acc, item) => {
      const key = `${item.employee}-${item.project}`;
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(item);
      return acc;
    }, {} as { [project: string]: Item[] });
  }

  getProjects(): string[] {
    return Object.keys(this.groupedData);
  }

  getProjectCount(project: string): number {
    return this.groupedData[project]?.length || 0;
  }

  getEmployeeProjects(employee: string): string[] {
    return this.jsonData.filter(item => item.employee === employee)
      .map(item => item.project)
      .filter((value, index, self) => self.indexOf(value) === index);
  }

  getProjectCountForEmployee(employee: any, project: any): number {
    this.recordCount = this.jsonData.filter(item => item.employee === employee && item.project === project).length;
   this.t=this.t+this.recordCount;
    return this.recordCount ? 1 : 0;
  }

  ngOnInit(): void {
    this.fetchData();
    
  }
  
}
