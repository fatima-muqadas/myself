import { Component } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { Router } from '@angular/router';
import { OnInit } from '@angular/core';
@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {
  public name:string ='';
  constructor  (private route: ActivatedRoute, private router:Router) {}
  ngOnInit(): void {
    
    
  }
  gotopage(): void{
    this.router.navigate(['/shoplist'])
  }
  
}












