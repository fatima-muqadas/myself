import { Component } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';

import { ActivatedRoute} from '@angular/router';
import { Router } from '@angular/router';
import { OnInit } from '@angular/core';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  title ='my-app';
  constructor  (private route: ActivatedRoute, private router:Router) {}
  ngOnInit(): void {
    
    
  }
  gotopage(): void{
    this.router.navigate(['/signup'])
  }
  loginForm = new FormGroup({
    email:new FormControl(''),
    password:new FormControl(''),
  })
  loginuser()
  {
    console.warn(this.loginForm.value)
  }
}
