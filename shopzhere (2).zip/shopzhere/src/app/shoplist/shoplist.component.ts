import { Component } from '@angular/core';

@Component({
  selector: 'app-shoplist',
  templateUrl: './shoplist.component.html',
  styleUrls: ['./shoplist.component.css']
})
export class ShoplistComponent {

  url: string = "https://images.pexels.com/photos/376464/pexels-photo-376464.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
    imageChange(event: any){
        this.url = event.target.src;
    }
    url1: string = "https://images.pexels.com/photos/7340956/pexels-photo-7340956.jpeg?auto=compress&cs=tinysrgb&w=600";
    imageChange1(event: any){
        this.url1 = event.target.src;
    } 
    url2: string = "https://images.pexels.com/photos/1146760/pexels-photo-1146760.jpeg?auto=compress&cs=tinysrgb&w=600";
    imageChange2(event: any){
        this.url2 = event.target.src;
    } 
    url3: string = "https://images.pexels.com/photos/803963/pexels-photo-803963.jpeg?auto=compress&cs=tinysrgb&w=600";
    imageChange3(event: any){
        this.url3 = event.target.src;
    } 
    
}
