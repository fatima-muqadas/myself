import { Component, OnInit } from '@angular/core';

import { DataserviceService} from '../dataservice.service';


interface Item {
  No?: number;
  name?: string;
  title?: string;
 
  project:string;
}

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent {
 
   resource: any[] = [];
   task: any[] = [];


  constructor(private dataService: DataserviceService) {}

  ngOnInit(): void {
    this.dataService.getData1().subscribe(response=>{
      this.resource=response;
      console.log(this.resource);
      this.groupData(this.resource);
      console.log(this.groupedData);

    });
    this.dataService.getData2().subscribe(response=>{
      this.task=response;
      console.log(this.task);
      this.groupData(this.task);
    console.log(this.groupedData);
    });
  }
  groupedData: { [key: string]: Item[] } = {};
  groupData(data: Item[]) {
    data.forEach(item => {
      if (!this.groupedData[item.project]) {
        this.groupedData[item.project] = [];
        
      }
      this.groupedData[item.project].push(item);
      
    });
  }
  getTotalNoForProject(projectKey: string): number {
  const projectData = this.groupedData[projectKey];
  if (!projectData) {
    return 0;
  }

  let totalNo = 0;
  projectData.forEach((item) => {
    totalNo += item.No || 0;
  });

  return totalNo;
}
 
}

 
  
  





















        
              





