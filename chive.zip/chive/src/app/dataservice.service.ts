import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataserviceService {

  constructor(private http: HttpClient) {}

 getData1(): Observable<any> {
   return this.http.get('assets/list.json');
 }

 getData2(): Observable<any> {
   return this.http.get('assets/project.json');
 }
}
