import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as XLSX from 'xlsx';




interface Item {
  [key: string]: any;
  employee?: string;
  Taskid: number;
  Descryption: string;
  project: string;
}

@Component({
  selector: 'app-data-viewer',
  templateUrl: './data-viewer.component.html',
  styleUrls: ['./data-viewer.component.css']
})
export class DataViewerComponent implements OnInit {
  jsonData: Item[] = [];
  filteredData: any[] = [];
  whereConditions: { field: keyof Item; value: string | number }[] = [];
  fields: (keyof Item)[] = ['employee', 'Taskid', 'Descryption', 'project'];
  newField: keyof Item = 'employee';
  newValue: string = '';
  abc:any;
  abcd:any;
  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.fetchData();
     this.abc=history.state.employee;
     this.abcd=history.state.project;

  }

  fetchData(): void {
    this.http.get<Item[]>('/assets/data.json').subscribe((data) => {
      this.jsonData = data;
      this.filteredData=[];
      this.jsonData.forEach((record)=>{
          if(record.employee==this.abc && record.project==this.abcd)
          {
            this.filteredData.push(record);
          }
      });
      console.log(data)
     // this.applyWhereConditions();
    });
  }

  addWhereCondition(field: keyof Item, value: string | number): void {
    this.whereConditions.push({ field, value });
    this.applyWhereConditions();
  }

  removeWhereCondition(index: number): void {
    this.whereConditions.splice(index, 1);
    this.applyWhereConditions();
  }

  applyWhereConditions(): void {
    this.filteredData = this.jsonData.filter((item) => {
      for (const condition of this.whereConditions) {
        if (item[condition.field] !== condition.value) {
          return false;
        }
      }
      return true;
    });
  }

  exportToExcel(): void {
    const exportData: any[] = [];

    // Add headers
    const headerRow: any = {};
    for (const field of this.fields) {
      headerRow[field] = field;
    }
    exportData.push(headerRow);

    // Add rows
    for (const item of this.filteredData) {
      const rowData: any = {};
      for (const field of this.fields) {
        rowData[field] = item[field];
      }
      exportData.push(rowData);
    }

    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(exportData);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };

    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, 'table_data');
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url: string = window.URL.createObjectURL(data);
    const a: HTMLAnchorElement = document.createElement('a');
    a.href = url;
    a.download = fileName + '.xlsx';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }
  applyWhereCondition(field: keyof Item, item: Item): void {
    if (field === 'employee' && item.employee) {
      this.addWhereCondition('employee', item.employee);
    } else if (field === 'project' && item.project) {
      this.addWhereCondition('project', item.project);
    }
  }
}
