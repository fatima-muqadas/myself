import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { InterfaceComponent } from './interface/interface.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { DataViewerComponent } from './data-viewer/data-viewer.component';
import { DataComponent } from './data/data.component';

const routes: Routes = [
  {path:'data-viewer',component: DataViewerComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule,HttpClientModule,CommonModule,
    FormsModule]
})
export class AppRoutingModule { }
